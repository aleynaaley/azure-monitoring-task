Azure resources automatically collect platform metrics and send them to Azure Monitor Metrics. The following diagram shows the process of using a DCR to send this data to a Log Analytics workspace for analysis using log queries. This process replaces the current method of using [[Diagnostic Settings]] to perform this function.

When the DCR is created, it specifies the workspace and table where the data should be sent. The DCR also includes a transformation that ensures the data is in the correct format for the target table. The DCR is then associated with the resource from which the platform metrics are collected.

![[Pasted image 20260925021407.png]]