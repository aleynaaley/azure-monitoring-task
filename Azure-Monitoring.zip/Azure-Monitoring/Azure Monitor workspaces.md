Azure Monitor workspaces will eventually contain all metric data collected by Azure Monitor. Currently, only Prometheus metrics are data hosted in an Azure Monitor workspace.(https://learn.microsoft.com/en-us/azure/azure-monitor/metrics/azure-monitor-workspace-overview)

These metrics can be queried using PromQL and visualized through Azure Monitor and related tools.

Example:
Guest OS → OpenTelemetry metrics → Azure Monitor Workspace → PromQL

![[Pasted image 20260924234819.png]]