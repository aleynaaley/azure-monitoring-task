[Azure VMs have several layers that require monitoring. Each of the following layers has a distinct set of telemetry and monitoring requirements.](https://learn.microsoft.com/en-us/training/modules/monitor-azure-vm-using-diagnostic-data/2-monitor-vm-health)


![[Pasted image 20260925143316.png]]

Azure automatically collects basic metrics for VM hosts. On the VM's Overview page in the Azure portal, you can see built-in graphs for the following important VM host metrics.

Host monitoring:

![[Pasted image 20260925153123.png]]


Guest OS monitoring:

First, I created the LAW, then the DCR. I will determine what data is to be collected and where it will be stored.

![[law.png|467]]![[DCR.png|540]]

![[Pasted image 20260925162253.png]]

When creating the DCR from the portal, I selected the VM I had created myself in the resource section.

[The recommended way to install the Azure Monitor Agent through the Azure portal is to create a data collection rule (DCR). The Azure Monitor Agent installs automatically if necessary, and an association is created between the DCR and each machine you select.](https://learn.microsoft.com/en-us/azure/azure-monitor/vm/monitor-virtual-machine-agent)

![[Pasted image 20260925163608.png]]


![[Pasted image 20260925164435.png]]


## Enable enhanced monitoring for an Azure virtual machine

[Virtual machines in Azure automatically send host-level metrics to Azure Monitor, which provide insights into the overall performance and health of the virtual machine. For complete monitoring though, you also need to collect guest-level performance data from the virtual machine, which provides insights into the applications, components, and processes running on the machine and their performance and health.](https://learn.microsoft.com/en-us/azure/azure-monitor/vm/tutorial-enable-monitoring)

[When you enable enhanced monitoring  you choose between two experiences for collecting and visualizing performance data from the guest operating system: OpenTelemetry metrics-based monitoring (recommended for new deployments) and logs-based monitoring (classic).](https://learn.microsoft.com/en-us/azure/azure-monitor/vm/metrics-opentelemetry-guest#compare-experiences )

![[Pasted image 20260925165646.png]]

![[confmonitor.png]]

![[Pasted image 20260925165814.png]]

