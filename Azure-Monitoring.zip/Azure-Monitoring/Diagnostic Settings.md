[You can use diagnostic settings in Azure Monitor to collect resource logs and to send platform metrics and the activity log to various destinations. Create a separate diagnostic setting for each resource that you want to collect data from. Each setting defines the data from the resource to collect and the destinations to send that data to.](https://learn.microsoft.com/en-us/azure/azure-monitor/data-collection/diagnostic-settings?tabs=portal)


![[Pasted image 20260925005401.png|639]]



![[Resim1.png|484]]