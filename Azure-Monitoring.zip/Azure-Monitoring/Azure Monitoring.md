## Azure Monitoring

[Azure Monitor is Microsoft's unified observability service for collecting, analyzing, and acting on telemetry from cloud and hybrid environments. It enables you to understand the health, performance, and reliability of your Azure applications and infrastructure resources by bringing together metrics, logs, traces, and events into a single observability experience.](https://learn.microsoft.com/en-us/azure/azure-monitor/fundamentals/overview)

## Monitoring Data
→ [[Monitoring Data]]

## Data Platform
→ [[Data Platform]]

## Data Collection
→ [[Data Collection]]

## Virtual Machine Monitoring 
→ [[Virtual Machine Monitoring]]

## Analysis and Response 
→ [[Analysis and Response]]


