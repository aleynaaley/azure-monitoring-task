[Alerts help you detect and address issues before users notice them by proactively notifying you when Azure Monitor data indicates there might be a problem with your infrastructure or application.](https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-overview)

You can alert on any metric or log data source in the Azure Monitor data platform. 
![[Pasted image 20260925171238.png]]

![[Pasted image 20260925171653.png]]
![[Pasted image 20260925171925.png]]