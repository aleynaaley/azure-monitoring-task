[Azure Monitor has a centralized data platform to support collection of telemetry from a variety of sources and the different features for analysis and troubleshooting. The platform uses two workspace types, each optimized for different data:](https://learn.microsoft.com/en-us/azure/azure-monitor/fundamentals/overview)

- [[Log Analytics workspaces]] collect log and trace data, which can be analyzed with Kusto Query Language (KQL).

- [[Azure Monitor workspaces]] collect Prometheus and OpenTelemetry metrics, which can be analyzed using Prometheus Query Language (PromQL).