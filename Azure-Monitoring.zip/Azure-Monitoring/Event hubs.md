Azure Event Hubs is an event streaming service that ingests large volumes of data in real time and stores or forwards it so that other systems can access it.

When the Event Hub receives data, it forwards it to Azure Monitor. A Data Collection Rule Association (DCRA) is created between the Event Hub and the DCR. Azure Monitor then applies the transformation defined in the DCR to the data and sends it to the destination specified in the DCR.

![[eh.png|460]]![[eh2.png]]