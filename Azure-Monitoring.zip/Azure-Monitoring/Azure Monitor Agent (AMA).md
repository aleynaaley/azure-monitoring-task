[The Azure Monitor Agent collects monitoring data from the guest operating system of Azure and hybrid virtual machines (VMs). It delivers the data to Azure Monitor for use by features, insights, and other services, such as Microsoft Sentinel and Microsoft Defender for Cloud.](https://learn.microsoft.com/en-us/azure/azure-monitor/agents/azure-monitor-agent-overview)

The Azure Monitor Agent collects data according to [[Data Collection Rules (DCRs)]] associated with the agent. DCRs define what data is collected, how it gets processed, and where it gets sent.

When you install the agent, it retrieves and applies any associated DCRs and periodically checks for updates. It enables centralized and consistent configuration of data collection across multiple agents and environments.
![[Pasted image 20260925020617.png]]
