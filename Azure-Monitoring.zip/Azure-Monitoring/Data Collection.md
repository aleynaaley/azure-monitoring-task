Azure Monitor collects monitoring data from various sources. Different data sources may use different data collection methods, and each may require different configurations. The collected data can be processed and subsequently sent to one or more destinations.
The main collection methods used in this study are:

- [[Diagnostic Settings]]
- [[ Data Collection Rules (DCRs)]]
- [[Azure Monitor Agent (AMA)]]

