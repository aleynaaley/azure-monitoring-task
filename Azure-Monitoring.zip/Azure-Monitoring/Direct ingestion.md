Use direct ingestion to specify a particular DCR to process the incoming data. For example, the following diagram illustrates data from a custom application using Logs ingestion API. Each API call specifies the DCR that processes its data. The DCR understands the structure of the incoming data, includes a transformation that ensures the data is in the format of the target table, and specifies a workspace and table to send the transformed data.



![[Pasted image 20260925021635.png]]
![[Pasted image 20260925021931.png]]

https://learn.microsoft.com/en-us/azure/azure-monitor/data-collection/data-collection-rule-overview
