The data collection process that DCRs support provides a common processing path for incoming data. Each data collection scenario is defined in a DCR. The DCR provides instructions for how Azure Monitor should process the data it receives. Depending on the scenario, DCRs specify all or some of the following items:

- Data to collect and send to Azure Monitor.
- Schema of the incoming data.
- Transformations to apply to the data before it's stored.
- Destination where the data should be sent.

![[Pasted image 20260925013355.png]]
After you create a DCR, use different methods to use it based on the data collection scenario. The following table lists common scenarios and the method used to collect data in each case. The following sections provide more details on each method.

Scenario:

| Scenario                         | Method                                                              |
| -------------------------------- | ------------------------------------------------------------------- |
| [[Azure Monitor agent (AMA)]]    | Data collection rule association (DCRA)                             |
| [[Event hubs]]                   | Data collection rule association (DCRA)                             |
| [[Platform metrics ]]            | Data collection rule association (DCRA)                             |
| [[Direct ingestion]]             | DCR specified in the API call that sends the data to Azure Monitor. |
| [[Workspace transformation DCR]] | DCR is applied directly to the workspace.                           |


https://learn.microsoft.com/en-us/azure/azure-monitor/data-collection/data-collection-rule-overview