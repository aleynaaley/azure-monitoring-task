[Workspace transformation DCRs provide transformations for data collection that don't use a DCR. They're applied directly to the Log Analytics workspace. After you create or update the DCR, allow some time for transformations to take effect on incoming data.](https://learn.microsoft.com/en-us/azure/azure-monitor/data-collection/data-collection-rule-overview)

![[Pasted image 20260925022010.png]]

