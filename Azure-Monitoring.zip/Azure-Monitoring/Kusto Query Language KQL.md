[You use Kusto Query Language (KQL) to write queries in Azure Data Explorer, Azure Monitor Log Analytics, Microsoft Sentinel, and more.](https://learn.microsoft.com/en-us/kusto/query/tutorials/learn-common-operators?view=azure-data-explorer&preserve-view=true&pivots=azuremonitor)

Str:
Table
| operator
| operator


```
StormEvents
| count
```


| Operation                     | KQL Operator        | Description                                                                                                                                           |     |
| ----------------------------- | ------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- | --- |
| **Count rows**                | `count`             | Returns the number of rows in the table.                                                                                                              |     |
| **View sample data**          | `take`              | Returns the specified number of random rows from the table. It can be used to inspect the general structure and content of the data.                  |     |
| **Select specific columns**   | `project`           | Selects the specific columns to be displayed in the results.                                                                                          |     |
| **List unique values**        | `distinct`          | Lists the unique values in the specified column.                                                                                                      |     |
| **Filter by condition**       | `where`             | Filters rows that meet the specified criteria.                                                                                                        |     |
| **Filter by date/time range** | `between`           | Can be used to filter data within a specific value or time range.                                                                                     |     |
| **Sort results**              | `sort`              | Sorts rows according to the specified column. The default sort order is descending (`desc`); ascending order can be specified using `asc`.            |     |
| **Get the first n rows**      | `top`               | Returns the first `n` rows after sorting the data by the specified column.                                                                            |     |
| **Create calculated columns** | `project`, `extend` | `project` can create a calculated column while selecting the columns to display. `extend` adds a new calculated column to the existing table columns. |     |

```
StormEvents
| take 5 
| project State, EventType, DamageProperty
```

```
StormEvents 
| where State == 'TEXAS' and EventType == 'Flood' 
| sort by DamageProperty 
| project StartTime, EndTime, State, EventType, DamageProperty
```


![[Pasted image 20260925180813.png|608]]